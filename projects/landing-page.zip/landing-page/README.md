# Landing Page Project

The project works as per rubric: whenever you click on a button it takes you to that section and adds background to it, same happens if you scroll towards that section. 

Everything works through app.js. 

## optional TODOs
Add timeout for scrolling
Hide bar while scrolling
Add "back to top button"